package gasbookingproject;
import java.util.*;
import java.time.LocalDate;
import java.time.LocalTime;
public class GasBooking
{
       public static void main(String args[])
       {
           GasBook gasbook=new GasBook();
           Scanner sc=new Scanner(System.in);
           System.out.println();
           
           int length=0;
           int ans;
           int counter=0;
           System.out.println("WELCOME TO AASHAY AND JIGNESH GAS BOOKING SERVICE");
           CustomerConnection customer[]=new CustomerConnection[100];
           long arr[]=new long[100];
           long customerid1=11111;
          
           try
           {
           do
           {
               System.out.println(LocalDate.now());
               System.out.println(LocalTime.now());
               System.out.println();
               System.out.println("DEAR USER KINDLY SELECT BELOW OPTIONS");
             
               System.out.println("1. GAS BOOKING \n2. CUSTOMER DETAILS \n3. NEW GAS CONNECTION \n4. REMOVE GAS CONNECTION \n5. MODIFIED CUSTOMER DETAILS \n6. HELPLINE \n7. PRINT ALL CUSTOMER PREVIOUS TO NOW DATA (ADMIN ONLY)");
               int option=sc.nextInt();
            

               switch(option)
               {
                    case 1:
                      
                      System.out.print("KINDLY ENTER YOUR UNIQUE CUSTOMER ID :");
                      long custId=sc.nextLong();
                      if(gasbook.equal(custId))
                      { 
                         System.out.println("CUSTOMER ID SUCCESSFULLY MATCHED:");
                        System.out.print("KINDLY PAY 714 RS YOUR FILL CYLINDER COST :");
                          int pay=sc.nextInt();
                          if(pay==714)
                          {
                            int k;
                        for(k=0;k<arr.length;k++)
                        {
                             if(arr[k]==custId)
                             {
                                 break;
                             }
                        }
                        customer[k].printCustName();
                        System.out.println();
                        gasbook.dequeue();
                        System.out.println();
                        System.out.println("YOUR PREVIOUS UNFILL GAS AUTOMATICALLY SUBMITTED BECAUSE YOU ARE GETTING FILLONE:");
                        gasbook.enqueue(custId);
                          }
                          else
                          {
                              System.out.println("YOU ENTERED WRONG AMMOUNT PLEASE TRY AGAIN");
                          }
                       }
                      else
                        {
                          System.out.println("YOU HAVE ENTERED WRONG CUSTOMER ID PLEASE FOLLOW PROCEDURE");
                          System.out.println();
                        }
                       
                        
                        break;
                    case 2: 
                     
                      System.out.print("KINDLY ENTER YOUR UNIQUE CUSTOMER ID :");
                      long cuid=sc.nextLong();
                      int i;
                      for(i=0;i<arr.length;i++)
                         if(arr[i]==cuid)
                         {
                             
                           break;
                         }
                         if(i==arr.length)
                         {
                           System.out.println("THIS CUSTOMER ID NOT VALID");
                           break;
                         }
                         else
                         {
                            customer[i].printDetails();
                            break;
                         }
                     
                    case 3:
                      System.out.print("DEAR CUSTOMER PLEASE PAY INITIAL AMMOUNT 5000 RS :");
                      int ammount=sc.nextInt();
                      if(ammount==5000)
                      {
                      
                      System.out.print("ENTER CUSTOMER NAME HERE : ");
                      sc.nextLine();
                      StringBuffer name=new StringBuffer(sc.nextLine());
                      System.out.print("ENTER CUSTOMER CONTACT NUMBER HERE : ");
                      long contact=sc.nextLong();
                      arr[counter]=customerid1;
                      System.out.print("ENTER CUSTOMER ADDRESS HERE : ");
                      sc.nextLine();
                      StringBuffer adrs=new StringBuffer(sc.nextLine());
                      StringBuffer status=new StringBuffer("ACTIVE");
                      customer[counter]=new CustomerConnection(name,customerid1,adrs,contact,status);
                      gasbook.enqueue(customerid1);
                      System.out.println();
                      System.out.println("DEAR CUSTOMER YOU GET YOUR FIRST CYLINDER");
                      System.out.println("CONGRATULATIONS YOU HAVE SUCCESSFULLY REGISTERD FOR HP GAS SERVICE");
                      System.out.println("YOU GET YOUR CUSTOMER ID KINDLY NOTEDOWN IT  :"+customerid1);
                      customerid1++;
                      length++;
                      counter++;
                      }
                      else
                      {
                          System.out.println("PLEASE PAY CORRECT AMMOUNT");
                      }
                        break;
                    case 4:
                      System.out.print("KINDLY ENTER YOUR UNIQUE CUSTOMER ID TO DISCONNECT CONNECTION :");
                      long cuid2=sc.nextLong();
                       if(gasbook.equal(cuid2))
                       {
                      System.out.print("REMOVE GAS CONNECTION ENTER Y/N:");
                      char char1=sc.next().charAt(0);
                      if(char1=='y' || char1=='Y')
                      {
                      int temp;
                      for(temp=0;temp<arr.length;temp++)
                         if(arr[temp]==cuid2)
                         { 
                           break;
                         }
                        int ai=temp;
                         if(temp==arr.length)
                         {
                           System.out.println("THIS CUSTOMER ID NOT VALID");
                           break;
                         }
                         else
                         {
                          for(int k=temp;k<arr.length-1;k++)
                          {
                              arr[k]=arr[k+1];
                          }
                          StringBuffer stat=new StringBuffer("INACTIVE");
                          customer[ai].modifyStatus(stat);
                         System.out.println();
                          System.out.println("YOUR HP GAS CONNECTION HAS BEEN DELETED SUCCESSFULLY");
                         }
                         }
                      
                      else
                      {
                          System.out.println("KINDLY ENTER Y FOR REMOVING CONNECTION");
                      }
                       }
                      else
                      {
                         System.out.println("THIS CUSTOMER ID NOT VALID");  
                      }
                      break;
                    case 5: 
                      System.out.print("KINDLY ENTER YOUR UNIQUE CUSTOMER ID :");
                      long cuid1=sc.nextLong();
                      int m;
                      if(gasbook.equal(cuid1))
                       {
                         for(m=0;m<arr.length;m++)
                         if(arr[m]==cuid1)
                         {
                         System.out.print("CUSTOMER ID SUCCESSFULLY MATCHED :");
                             break;
                         }
                         System.out.println("SELECT BELOW OPTIONS :\n1. CHANGE YOUR NAME \n2. CHANGE YOUR MOBILE NUMBER \n3. CHANGE CUSTOMER ADDRESS");
                        
                         System.out.println("ENTER NUMBER ABOVE OPTIONS :");
                         int cd=sc.nextInt();
                         switch(cd)
                        {
                            case 1 :
                                customer[m].printCustName();
                                System.out.print("ENTER CORRECTED NAME HERE :");
                                sc.nextLine();
                                StringBuffer Custname=new StringBuffer(sc.nextLine());
                                customer[m].modifyName(Custname);
                                break;
                            case 2 :
                                customer[m].printCustContact();
                                System.out.print("ENTER CORRECTED NUMBER HERE :");
                                long cnum=sc.nextLong();
                                customer[m].modifyContact(cnum);
                                break;
                            case 3 :
                                customer[m].printCustAddress();
                                System.out.print("ENTER CORRECTED ADDRESS HERE :");
                                sc.nextLine();
                                StringBuffer CustAdd=new StringBuffer(sc.nextLine());
                                customer[m].modifyAddress(CustAdd);
                                 break;
                            default :
                                System.out.print("YOU HAVE SELECT WRONG OPTION :");
                                break;
                        }
                       }
                     else{
                         System.out.println("ENTERED WRONG CUSTOMER ID :");
                         
                         }
                      break;
                    case 6: 
                      System.out.println("complaints/suggestions by calling company representatives");
                      System.out.println("Toll Free customer care number : 1800 2333 444");
                      System.out.println("Website : www.aashayjigneshhpbookin.in");
                      System.out.println("Email Id : aashayjigneshservices@gmail.com");
                      break;
                    case 7:
                        
                      System.out.println("PRINT ALL CUSTOMER PAST CONNECTIONS RECORDS"); 
                      System.out.print("ENTER ADMIN PASSWORD HERE :");
                      sc.nextLine();
                      String password=sc.nextLine();
                      CustomerConnection cc=new CustomerConnection(password);
                      if(length>0)
                      {
                      try{
                      if(cc.AllCustDetails())
                      {
                        for(int c=0;c<customer.length;c++)
                        {
                            System.out.println();
                           customer[c].printDetails(); 
                        }
                      }
                     
                      else
                      {
                          System.out.println("ENTERED WRONG PASSWORD");
                      }
                      }
                      catch(Exception e)
                      {
                          System.out.println();
                          System.out.println("CUSTOMER DETAILS PRINTED");
                      }
                      }
                      else
                      {
                         System.out.println("NO CUSTOMER REGISTRATION");
                      }
                       
                      
                      break;
                    default: 
                      System.out.println("DEAR CUSTOMER YOU HAVE ENTERED WRONG OPTION PLEASE SELECT CORRECT ONE");
                      break;
                   }
            
              System.out.println("DO YOU WANT TO CONTINUE Y/N");
              ans=sc.next().charAt(0);
               }
          while(ans=='y' || ans=='Y' );
            }
          catch(InputMismatchException e)
          {
              System.out.println("KINDLY SELECT CORRECT OPTION/NUMBER/VALUE AND FOLLOW PROCEDURE AGAIN");
          }
       
          
       }
}
