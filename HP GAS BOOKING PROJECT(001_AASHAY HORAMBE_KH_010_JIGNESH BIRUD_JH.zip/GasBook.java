package gasbookingproject;
import java.util.*;
 public class GasBook
{
  int front=0, rear=-1;
  long cylinder[]=new long[100];
  int size=cylinder.length;
  int counter; 
  public GasBook() 
    { 
      
    } 
   void enqueue(long x)
    { 
        rear=(rear+1)% size;
       cylinder[rear] = x; 
        counter++;
        System.out.println();
    } 

    void dequeue() 
    { 
        long temp = cylinder[front];
        front = front % size;
        counter--;
        front++;
        System.out.println("YOU HAVE SUCCESSFULLY GET CYLINDER");
    } 
    boolean equal(long check)
    { boolean flag=false;
        for(int i=0;i<cylinder.length;i++)
        {
            if(cylinder[i]==check)
            {
               flag=true;
               break;
            }
        }
        if(flag==true)
        return true;
        else
        return false;
    }
  
}