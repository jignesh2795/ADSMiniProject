package gasbookingproject;

class CustomerConnection
{
      private StringBuffer customerName;
      private long custUniqId;
      private StringBuffer custAddress;
      private long custContact; 
      private String password;
      private String pwd="Service@123";
      private StringBuffer status;
      public CustomerConnection(StringBuffer customerName,long custUniqId,StringBuffer custAddress,long custContact,StringBuffer status)
      {
          this.customerName=customerName;
          this.custUniqId=custUniqId;
          this.custAddress=custAddress;
          this.custContact=custContact;
          this.status=status;
          
      }
      public CustomerConnection(String password)
      {
          this.password=password;
      }
      
      public void printDetails()
      {
         System.out.println("CUSTOMER NAME :"+customerName);
         System.out.println("CUSTOMER ADDRESS :"+custAddress);
         System.out.println("CUSTOMER contact :"+custContact);
         System.out.println("CUSTOMER contact :"+status);
      }
      public void printCustName()
      {
          System.out.println("YOUR REGISTERED NAME IS "+customerName);
      }
      public void printCustAddress()
      {
          System.out.println("YOUR REGISTERED ADDRESS IS "+custAddress);
      }
      public void printCustContact()
      {
          System.out.println("YOUR REGISTERED CONTACT NUMBER IS "+custContact);
      }
      public void modifyName(StringBuffer name)
      {
          this.customerName=name;
      }
      public void modifyContact(long contact)
      {
          this.custContact=contact;
      }
      public void modifyAddress(StringBuffer address)
      {
          this.custAddress=address;
      }
       public void modifyStatus(StringBuffer stat)
      {
          this.status=stat;
      }
      boolean AllCustDetails()
      {
          if(password.equals(pwd))
          {
          
              return true;
              
          }
          else
          {
             return false;
          }
      }
    
}
